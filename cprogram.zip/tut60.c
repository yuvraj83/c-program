#include<stdio.h>
#include<stdlib.h>
int main()
{
   /* printf("file name is %s\n",__FILE__);
    printf("today DATE is %s\n",__DATE__);
      printf("time now is %s\n",__TIME__); */
      printf("Line No is %d\n",__LINE__);
      printf("ANSI: %d\n",__STDC__);
     
    return 0;
}
//OUTPUT:
/*file name is tut60.c
today DATE is Jan 25 2023
time now is 00:24:31*/