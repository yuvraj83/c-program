#include<stdio.h>
#include<stdlib.h>
int main()
{
    //Dynamic memory allocation problem
    //ABC Pvt Ltd manage record of other companies
    //Employeee id can be of any length and it can contain any character.
    //for 3 employees,you have to take length of employee id as input in alength integer variable.
    //then,you have to take employee id as an input and dissplay it on screen.
    //store the employee id in a character array which is allocated dynammically.
    //you have to create only one characteer directly.
    //EXAMLE 1:
    //Enter no of character in your Id
    //45
    //dynamically allocate the character array.
    //take input from user

    //EXAMLE 2:
    //Enter no of character in your Id
    //54
    //dynamically allocate the character array.
    //take input from user

    //EXAMLE 3:
    //Enter no of character in your Id
    //67
    //dynamically allocate the character array.
    //take input from user
    
    return 0;
}