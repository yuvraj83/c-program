#include<stdio.h>
//print fibbonacci series by iterative and recursive method time calculated
int main(int argc, char const *argv[])
{
    printf("the fibbonaci sefries is");
    return 0;
}
