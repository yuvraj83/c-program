//FUNCTION POINTER

#include<stdio.h>
#include<stdlib.h>

int sum(int a ,int b){
    return a+b;
}
void greet(){
    printf("Hello world my user good morning %d \n");
}
int main()
{

    printf("the sum of 1 and 2 is %d \n",sum(1,2));//testing the function 
    int(*fptr)(int,int);//declaring a function pointer 
    fptr =&sum;//creating a function pointer 
    int d = (*fptr)(4,6);  //Dereferencing a function pointer
    printf("The  value of d is %d\n",d);

    return 0;

}
/*OUTPUT:
the sum of 1 and 2 is 3 
The  value of d is 10
*/