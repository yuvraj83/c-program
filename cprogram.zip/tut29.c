//WHY WAS RECURSIVE APPROACH NOW
//Recursion is a good approach when it comes to problem solving
//however ,a programmer needs to evaluate the need and impact of using recursive/iterative approach while solving a particular problem.
//in case of factorial calculationrecursion saved a lot of lines of code
//however in case of fibbonacci series,recursion resultedin some extra unnecessary function calls which was an overhead!
//running time for fibbonaci series grows exponentially with input in case of rercursive approach!