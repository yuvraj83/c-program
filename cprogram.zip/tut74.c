#include<stdio.h>
#include<math.h>
int Edistance(int x1,int y1,int x2,int y2){
    return 0;
}

//float areaofcircle (int x1,int y1,int x2,int y2,<function pointer here>)
int main()
{
    //take x1,y1 and x2,y2 from the user using scanf
    return 0;
}
//eucledian distance formula