                       /*LOOPS*/
                       /* FOR LOOP*/
                       /*WHILE LOOPS*/
                       /*DO WHILE LOOPS*/
                       /*WHY DO YOU PROGRAM?*/
                       //print 1 to 1000

    // ADVANTAGE OF USING LOOPS
    /*1).CODE REUSEABILITY
    2).Saves time
    3).TRAVERSING(hold)
    */
   //basic syntax check the condition execute the loop nad false exit the loop