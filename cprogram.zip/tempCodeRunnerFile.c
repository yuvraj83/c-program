 // while (string[strlen(string) + 1] =='')  
            // {
            //     string[strlen(string)+1]='\0';
            // }