#include<stdio.h>
int main(int argc, char const *argv[])
{
    /* conver sion of units homework*/
    //km to miles,inches to foot ,cm to m and so on
    return 0;
}
