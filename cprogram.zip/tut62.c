//FILE I/O IN C
/*WHY DO WE NEED A FILE?
--->Files are used to store data and information
---->files are used and read and access data anytime from the hard disk.
--->files make it easy for a programmer to access and store content without losing it on program termination
*/
/* VOLATILE MEMORY
--->VOLATILE MEMORY is computer storage that only maintains its data while the device is powered
---->the ram will hold data ,programs and information as long as it has a constant power supply but immediately the powwer is interrrupted all that content is cleared.
--->the volatile memory will only hold data temporarly
*/
/*NON-VOLATILE-MEMORY
--->non volatile memory is computer memory that can retained the stored information even when not powered .
---->this type of memory is also refered to as permanent memory since data stored within it can be retrieved even when there is no constant power supply.
--->it is used for long term storage.
*/
/*WHY DO WE NEED FILES
--->when a c program is terminated ,the data stored in ram is lost.
---->storing in a file will preserve our data even after the program terminates
---->RAM is not able to ahndle quitee large amount of data due to its small size relative to the haard disk.
--->it is easy to transfer data files.
*/
/*TYPES OF FILES
They are two types of files
text files-->plain text
binary files-->(0 1) more security provide
*/
//in c we can perform these high level operation on files 
//creating the files --->
//opening the files 
//closing a file 
// reading from and writing to a file