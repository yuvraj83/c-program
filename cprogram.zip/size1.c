#include<stdio.h>
int main()
{
    /* code */
    printf("%lu",sizeof(int));
    return 0;
}
/*PS C:\Users\HP\Desktop\c-programs> gcc size1.c

PS C:\Users\HP\Desktop\c-programs> .\a.exe  
4 byte

similarly we can check size of all data types*/
