#include<stdio.h>
/* Print a multiplication table  of a number enterd by the user in pretty form
example:
input 
Enter the multiplication table of:*/

int main()
{ 
    int i,n;
for(int n=1;n<=10;n++)
{
    printf("table of 2 is %d\n:",2*n );
    
}

    return 0;
}
// printf("enter first number is:");
//     scanf("%d",&a);
//     printf("enter table of %d %d\n:",a*n);