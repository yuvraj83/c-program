//COMMAND LINE ARGUMENT
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
   /*you have to create a command line utility to add/subtract/multiply /divide two number 
    first command line argument  of your c programs must be the operation
    the enxt argument being the two numbers.*/
    return 0;
}