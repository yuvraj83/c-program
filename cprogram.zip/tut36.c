#include<stdio.h>
void arrayRev(arg1);
void arrayRev(arg1)
{

}
int main()
{
    int arr[] ={1,2,3,4,5,6,7};
    return 0;
}