//TYPECASTING syntax
//(type)value;
#include<stdio.h>
int main()
{
    int a = 3;
    float b = 54;
   // printf("the value of a is %d\n",(int)b);
    return 0;
}
//typecasting is the conversion of datatypes