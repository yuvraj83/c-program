#include<stdio.h>
#include<string.h>
int main()
{
    
    return 0;
}
// OUTPUT:
/*size tut45.exe
   text    data     bss     dec     hex filename
  14344    1532     112   15988    3e74 tut45.exe
*/