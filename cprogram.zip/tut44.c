#include<stdio.h>
int main()
{  /*
    you manage a travel agency and you wan your n driver to input their following details:
    1.Name
    2.Driving Liscence number
    3.Route
    4.Kms
    your program should be able to take n as input and your driver will start inputting their detail one by one
    your program should print details of the driver in a beautiful fashion.
    n=3 take
    
    */
    return 0;
}