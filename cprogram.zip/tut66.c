#include<stdio.h>
int main()
{
    //you have to fill in value in template letter.txt
    //letter.txt look something like this
    // thanks {{name}} for purchasing {{item}} from our outlet {{foutlet}}
    //please visit our outlet {{outlet}}  for any kind of problem. we plan to server you again soon
    //you have to read this file and replace these values 
    //{{name}} - harry
    //{{item}} - table fan
    //{{outlet}} - ram laxmi fan outlet
    //use file function in c to accomplish the same
    return 0;
}