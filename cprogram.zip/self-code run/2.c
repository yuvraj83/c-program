#include<stdio.h>
int main()
{
    int i, a,b,c,y,sum;
    printf("first number:\n");
    scanf("%d",&a);
    printf("2 number:\n");
    scanf("%d",&b);
    printf("3 number:\n");
    scanf("%d",&c);
        sum=(a+b+c);
  printf("the sum is %d\n",sum);
       y=sum/3;

    printf("the avg is  %d:\n",y);

    return 0;
}
#include<stdio.h>
int main()
{  char ch,a;
    printf("enter charactet\n");
    scanf("%c",&ch);
    if (ch>='a' && ch<='z'){
        printf("character is alphabet");
    }
    else if (ch>='A' && ch<='Z')
    {
        printf("character is alphabet");
    }


    else{
        printf("character is not alphabet");
    }
    return 0;
}
/*#include<stdio.h>
int main()
{  char ch,a;
    printf("enter character\n");
    scanf("%c",&ch);
    if (ch>='0' && ch<='9'){
        printf("character is digit");
    }
    else if ((ch>='A' && ch<='Z')||(ch>='a' && ch<='z'))
    {
        printf("character is alphabet");
    }


    else{
        printf("character is not digit");
    }
    return 0;
}*/
/*
#include <stdio.h>

int main()
{
    int i;
    int arr[] = {25, 11, 22, 33, 73, 56, 76}; // intitialize array

    // calculate length of array
    int length = sizeof(arr) / sizeof(arr[0]);
    // initialize min with first element
    int min = arr[0];

    // loop throught the aray
    for (i = 0; i < length; i++)
    {
        if (arr[i] < min)

            min = arr[i];
    }

    printf("smallest element %d\n", min);

    return 0;
}


*/

#include<stdio.h>
int main(){
   int i,j,a,n,counter,ave,number[30];
   printf ("Enter the value of N
");
   scanf ("%d", &n);
   printf ("Enter the numbers 
");
   for (i=0; i<n; ++i){
      scanf ("%d",&number[i]);
   for (i=0; i<n; ++i){
      for (j=i+1; j<n; ++j){
         if (number[i] < number[j]){
            a = number[i];
            number[i] = number[j];
            number[j] = a;
         }
      }
   }
   }
   printf ("The numbers arranged in descending order are given below
");
   for (i=0; i<n; ++i)
      printf ("%10d
",number[i]);
   printf ("The 2nd largest number is = %d
", number[1]);
   printf ("The 2nd smallest number is = %d
", number[n-2]);
   ave = (number[1] +number[n-2])/2;
   counter = 0;
   for (i=0; i<n; ++i){
      if (ave==number[i])
         ++counter;
   }
   if (counter==0)
      printf("The average of 2nd largest & 2nd smallest is not in the array
");
   else
      printf("The average of 2nd largest & 2nd smallest in array is %d in numbers
", counter);
return 0;
}
