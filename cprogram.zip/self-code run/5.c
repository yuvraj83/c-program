//PATTERN
//SOLID RECTANGUAR PATTERN IN C
#include<stdio.h>
int main()
{
    int rows,column,i,j;
    printf("enter rows");
    scanf("%d",&rows);
    printf("enter columns");
    scanf("%d",&columns);
    
    return 0;
}