/*#include<stdio.h>
int main()
{
    int i;
    printf("Enter an integer:");
    scanf("%d",&i);
    if (i%4==0||i%6==0||i%10==0||i%14==0)
    {
       printf("prime number:\n");
    }
    else
    {
        printf("not prime\n");
    }
    
    return 0;
}
#include<stdio.h>
int main()
{
    int n,i,flag=0;
    printf("Enter an integer:");
    scanf("%d",&n);
//0 and 1 are prime number
//change flagto 1 for non-prime number
    if (n==0||n==1)
    {
        flag = 1;
    }
    for ( i = 2; i <= n/2; i++)
    {
        //if n is divisible by i, then n is not prime
        //change flag to 1 for non-prime number

        if (n%i==0)
        {
            flag = 1;
            break;
        }
        
    }
    //flag is 0 for primenumbers
    if (flag==0)
    {
        printf("%d is a prime number.",n);
    }
    else{
         printf("%d is not prime number.",n);
    }
    
    

    return 0;
}
*/

//WRITE A PROGRAM TO PRINT PRIME NUMBER IN A RANGE.
/*#include<stdio.h>
#include<stdlib.h>
int main(){
    int num1,num2,i,j,flag,temp,count=0;
    printf("enter value of num1 and num2\n");
    scanf("%d%d",&num1,&num2);
    if (num2<2)
    {
        printf("there are no prime upto %d\n",num2);
        exit(0);
    }
    printf("prime number are\n");
    temp=num1;
    if (num1%2==0)
    {
        num1++;
    }
    for ( i = num1; i <= num2;i=i+2)
    {
        flag=0;
        for ( j = 2; j <= i/2; j++)
        {
            if ((i%j)==0)
            {
                flag=1;
                break;
            }
            if (flag==0)
            {
                printf("%d\n",i);
             count++;
            }
            
        }
        printf("Number of prime between %d%d=%d\n",temp,num2,count);
        
    }
    
    return 0;
}
*/
#include<stdio.h>
int main()
{
    int i,j;
    for (int i = 0; i < 5; i++)
    {
        
        for (int j = 0; j < 4; j++)
        {
            printf("*");
        }
        
        printf("\n");
        
    }
    

    return 0;
}
/*OUTPUT:
*****
*****
*****
*****
*****
*/