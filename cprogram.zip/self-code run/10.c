//WRITE A PROGRAM TO READ A STRING FROM A FILE AND OUTPUT TO THE USER
/*#include<stdio.h>


int main()
{
    FILE *fptr;
    fptr=fopen("file.txt","r");
char ch;
    //fprintf("enter character");
   ch = fgetc(fptr);
   while (ch!=EOF)
   {
    printf("%c",ch);
    ch = fgetc(fptr);
   }
    printf("\n");
   
    fclose(fptr);
    return 0;
}*/
/*#include<stdio.h>
#include<string.h>
    
 struct student
{
    char name[200];
    int marks;
    float cgpa;
    char courses[200];
};

int main()
{
 struct student s1={"yuvraj",76,7.8,"math"};
  //  s2={"sachin",85,8.4,"science"};

    printf("name=%s,marks=%d,cgpa=%f,course=%s",s1.name,s1.marks,s1.cgpa,s1.courses);
    
return 0;
}*/

/*#include <stdio.h>

  int main() {
        int num, large = 0, rem = 0;

        //get the input from the user 
        printf("Enter your input value:");
        scanf("%d", &num);

        // finding the largest digit of the given input 
        while (num > 0) {
                rem = num % 10;

                if (rem > large) {
                        large = rem;
                }

                num = num / 10;
        }

        // print the largest digit of the number 
        printf("Largest digit of the number is %d\n", large);
        switch (large)
        {
        case 1:
            printf("one");
            break;
            case 2:
            printf("one");
            break;case 3:
            printf("one");
            break;case 4:
            printf("one");
            break;case 5:
            printf("one");
            break;case 6:
            printf("one");
            break;case 7:
            printf("one");
            break;case 8:
            printf("one");
            break;
            case 9:
            printf("nine");
            break;
        
        default:
        printf("not find");
            break;
        }
        return 0;
  }
*/// CPP program to print a given number in words. The program
// handles numbers from 0 to 9999

#include <bits/stdc++.h>
using namespace std;

// A function that prints given number in words
void convert_to_words(char* num)
{
	int len = strlen(
		num); // Get number of digits in given number

	// Base cases
	if (len == 0) {
		fprintf(stderr, "empty string\n");
		return;
	}
	if (len > 4) {
		fprintf(stderr,
				"Length more than 4 is not supported\n");
		return;
	}

	/* The first string is not used, it is to make
		array indexing simple */
	char* single_digits[]
		= { "zero", "one", "two", "three", "four",
			"five", "six", "seven", "eight", "nine" };

	/* The first string is not used, it is to make
		array indexing simple */
	char* two_digits[]
		= { "",		 "ten",	 "eleven", "twelve",
			"thirteen", "fourteen", "fifteen", "sixteen",
			"seventeen", "eighteen", "nineteen" };

	/* The first two string are not used, they are to make
		array indexing simple*/
	char* tens_multiple[] = { "",	 "",	 "twenty",
							"thirty", "forty", "fifty",
							"sixty", "seventy", "eighty",
							"ninety" };

	char* tens_power[] = { "hundred", "thousand" };

	// Used for debugging purpose only
	cout << "\n" << num << ": ";

	// For single digit number
	if (len == 1) {
		cout << single_digits[*num - '0'] << "\n";
		return;
	}

	// Iterate while num is not '\0'
	while (*num != '\0') {

		// Code path for first 2 digits
		if (len >= 3) {
			if (*num - '0' != 0) {
				cout << single_digits[*num - '0'] << " ";
				cout << tens_power[len - 3]
					<< " "; // here len can be 3 or 4
			}
			--len;
		}

		// Code path for last 2 digits
		else {
			/* Need to explicitly handle 10-19. Sum of the
			two digits is used as index of "two_digits"
			array of strings */
			if (*num == '1') {
				int sum = *num - '0' + *(num + 1) - '0';
				cout << two_digits[sum] << "\n";
				return;
			}

			// Need to explicitly handle 20
			else if (*num == '2' && *(num + 1) == '0') {
				cout << "twenty\n";
				return;
			}

			// Rest of the two digit numbers i.e., 21 to 99
			else {
				int i = *num - '0';
				string tm = i ? tens_multiple[i] : "";
				cout << tm << " ";
				++num;
				if (*num != '0')
					cout << single_digits[*num - '0']
						<< " ";
			}
		}
		++num;
	}
}

// Driver program to test above function
int main()
{
	convert_to_words("9923");
	convert_to_words("523");
	convert_to_words("89");
	convert_to_words("8");

	return 0;
}

// This code is contributed by Susobhan Akhuli
