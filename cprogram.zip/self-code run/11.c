
//write a c program to read 1-d array prrint sum of all element along with inputtted array element using dynamic memory allocation

#include<stdio.h>
#include<stdlib.h>

int main()
{
    int *ptr;//declaratton of integer pointer 
    int limit;//to store array limit 
    int i;//loop counter
    int sum;//to store sum of all elements
    float avg ;
    printf("enter limit of the array:");
    scanf("%d",&limit);
    //declare memory dynamically
    ptr = (int*)malloc(limit * sizeof(int));
    //read array element
   for ( i = 0; i < limit; i++)
    {
        printf("enter element %02d:",i+1);
        scanf("%d",(ptr+i));
    }
    //print array element
    printf("enter array");
    for ( i = 0; i < limit; i++)
    {
        printf("%d\n",*(ptr+i));

    }
    
    //calculate sum of array element
      sum =0;
      for ( i = 0; i < limit; i++)
      { 
       
        sum+=*(ptr+i);
      }
        printf("sum array is:%d\n",sum);
        avg=sum/limit;
        printf("the avg is %f",avg);      
       free(ptr);
      return 0;
}