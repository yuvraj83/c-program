// IN AN ARRAY OF NUMBER X ,FIND HOW MANY TIMES A NUMBER X OCCUR
/*

 * C program to insert an element in a specified position in a given array

 */

#include <stdio.h>
void main()
{
    int array[100];
    int i, n, x, pos;
    printf("Enter the number of elements in the array \n");
    scanf("%d", &n);
    printf("Enter the elements \n");
        for (i = 0; i < n; i++)
    {
    scanf("%d", &array[i]);
    }
   printf("Input array elements are: \n");

    for (i = 0; i < n; i++)
    {

        printf("%d ", array[i]);
    }
        printf("\nEnter the new element to be inserted: ");
    scanf("%d", &x);
    printf("Enter the position where element is to be inserted: ");
    scanf("%d", &pos);
        //shift all elements 1 position forward from the place
    //where element needs to be inserted
    n=n+1;
    for(i = n-1; i >= pos; i--)
        array[i]=array[i-1];
    array[pos-1]=x; //Insert the element x on the specified position
        //print the new array
    for (i = 0; i < n; i++)
    {
        printf("%d ", array[i]);
    }
}
//IN AN ARRAY OF NUMBERS ,FIND HOW MANY TIMES DOES A NUMBER X OCCUR
/*#include <stdio.h>
int BinSearch(int arr1[], int n, int x, int searchFirst)
{
    int low = 0, high = n - 1;
    int result = -1;
    while (low <= high)
    {
        int mid = (low + high)/2;
        if (x == arr1[mid])
        {
            result = mid;
            if (searchFirst)
                high = mid - 1;
            else
                low = mid + 1;
        }
        else if (x < arr1[mid])
            high = mid - 1;
        else
            low = mid + 1;
    }
    return result;
}

int main(void)
{
    int arr1[] = {2, 3, 4, 4, 4, 4, 5, 5, 5, 6, 7, 7};
    int srch_num = 4;
    int n = sizeof(arr1)/sizeof(arr1[0]);
	int i;
 //------------- print original array ------------------	
	printf("The given array is :  ");
	for(i = 0; i < n; i++)
	{
	printf("%d  ", arr1[i]);
    } 
	printf("\n");
//------------------------------------------------------ 	
    int first = BinSearch(arr1, n, srch_num, 1); 
    int last = BinSearch(arr1, n, srch_num, 0);  
    int ctr = last - first + 1;
    if (first != -1)
        printf("The number of times the number %d occurs in the given array is:  %d", srch_num, ctr);
    else
        printf("No such element found in the array.");
    return 0;
}*/