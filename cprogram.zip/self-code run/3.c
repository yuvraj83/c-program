/*#include<stdio.h>
int main()
{
    int num;
    printf("enter number\n");
    scanf("%d",&num);
    if (num>=1)
    {
        printf("natural number:\n");
    }
    else{
        printf("not natural number");
    }
    

    return 0;
}*/
//write a c program to change the case of a character

#include<stdio.h>
int main()
{
    char upr,lwr;//declare variable
    int ascii;
    //convert lower case
    printf("upper case\n");
    scanf("%c",&upr);
    printf("lower case\n");
    scanf("%c",&lwr);
    ascii=upr+32;
    printf("%c character is lower case:%c\n",upr,ascii);
    // convert uppercase
    
    ascii=lwr-32;
    printf("%c character is upper case:%c\n",lwr,ascii);
    
    return 0;
}

//ARMSTRONG NUMBER abcd....=an+bn+cn
#include<stdio.h>
int main()
{
    int num,originalNum,remainder,result=0;
    printf("Enter a three-digit integer:");
    scanf("%d",&num);
    originalNum=num;
    while (originalNum !=0)
    {
        // remainder containes the last digit
        remainder = originalNum%10;
        result += remainder*remainder*remainder;
        //removing last digit from the original number
        originalNum /=10;
    }
    if (result==num)
    {
        printf("%d is an armstrong number.",num);
    }
    else{
         printf("%d is not armstrong number.",num);
    }  
    return 0;
}
/*#include<stdio.h>
#include<math.h>
int main()
{
    int num,originalNum,remainder,n=0;
    float result = 0.0;
    printf("Enter an integer:");
    scanf("%d",&num);
    originalNum=num;
    //store the number of digit of num in n
    for (originalNum = num; originalNum!=0;++n)
    {
        originalNum/=10;

    }
    for ( originalNum = num; originalNum!=0;originalNum/=10)
    {
      remainder = originalNum%10;
      //store the sum of the power of individual digits in result
      result += pow(remainder,n);
    }
    
    if ((int)result==num)
    {
        printf("%d is an armstrong number.",num);
    }
    else{
         printf("%d is not armstrong number.",num);
    }
    
    
    return 0;
}*/

#include<stdio.h>
int main()
{
    char upr,lwr;//declare variable
    int ascii;
    //convert upper case
    
    printf("lower case\n");
    scanf("%c",&lwr);
    if (lwr=='a'||lwr=='e'||lwr=='i'||lwr=='o'||lwr=='u')
    {
         ascii=lwr-32;
    printf("%c character is upper case:%c\n",lwr,ascii);
    }
    else{
        printf("character is not vowel and not change");
    }
    
    return 0;
}