/*#include<stdio.h>
void dowork(int a,int b,int *sum,int *subtract);
int main()
{
   int a,b;
    a=5;b=9;
    int sum,subtract;
    dowork(a,b,&sum,&subtract);
    
    printf("sum=%d,subtract=%d\n",sum,subtract);
    //printf("sum of two number is %d\n",a,b,*sum,*subtract);
    return 0;
}
void dowork(int a,int b,int *sum,int *subtract){
*sum=a+b;
*subtract=a-b;
}*/
/*#include<stdio.h>
int main()
{
    int i;
    int arr[] = {1,4,23,43,2,34,1};
    //calculate length of array
int length =sizeof(arr)/sizeof(arr[0]);
//initialize min with first element
int max = arr[0];

//loop throught the aray
for ( i = 0; i < length; i++)
{
    if (arr[i]>max)
    
        max=arr[i];
    
    
}

printf("maximum element %d\n",max);
   
    return 0;
}*/

//WRITE A PROGRAM IN C TO FIND MAXIMMUM NUMBER BETWEEN TWO NUMBER USING POINTER.
/*#include<stdio.h>
void max(int *a,int *b);
int main()
{
    int a,b;
    printf("enter number");
    scanf("%d%d",&a,&b);
    max(&a,&b);
    return 0;
}
void max(int *a,int *b){
    if (*a>*b)
    {
        printf("a is largest");
    }
    else{
        printf("b is largest");
    }
    
}*/
//WRITE A PROGRAM IN C TO PRINT ELEMENT OF ARRAY IN REVERSE ORDER.
/*#include<stdio.h>
void reverse(int arr[],int n);
void printArr(int arr[],int n);
int main()
{
   int arr[] = {1,2,3,4,5,6,7};
   reverse(arr,7);
   printArr(arr,7);
    return 0;
}
void printArr(int arr[],int n){
    for (int i = 0; i < n; i++)
    {
        printf("%d\t",arr[i]);
    }
    printf("\n");
    
}
void reverse(int arr[],int n){
    // printf("enter number");
    // scanf("%d",&n);
    for (int i = 0; i < n/2; i++)
    {
       int  firstval=arr[i];
       int  secondval=arr[n-i-1];
        arr[i]=secondval;
        arr[n-i-1]=firstval;
        
    }
    

}*/
/*#include<stdio.h>
int main()
{ char ch;

  //  printf("enter alphabet");
   //scanf("%c",&ch);
    // if( ch='a'||ch<='z')
    for (char ch = 'a'; ch <='z'; ch++)
    {
        printf("character is %c:\n",ch);
    }
    
    
    
    
    return 0;
}*/
/*#include<stdio.h>
#include<stdlib.h>

int main()
{

	char* c; 	// declare a character pointer
	c = (char*)malloc(sizeof(char));	// assigning memory to c

	*c = 'A';	// storing 'A' at the memeory that pointer c is pointing to

	// checking if the ASCII value of alphabet pointed by c
	// is less than equal to ASCII value of alphabet 'Z'
	while (*c <= 'Z') {

		printf("%c\n", *c);
		*c = *c + 1;	// increment the ASCII value of character that pointer c is pointing to

	}
}*/
#include<stdio.h>
#include<stdlib.h>

void PrintAlphabets(char* c) {

	// checking if the ASCII value of alphabet pointed by c
	// is less than equal to ASCII value of alphabet 'Z'
	if (*c <= 'Z') {
		printf("%c\n", *c);
		*c = *c + 1;	// increment the ASCII value of character that pointer c is pointing to
		PrintAlphabets(c);
	}
}
int main()
{
	char* c; 	// declare a character pointer
	c = (char*)malloc(sizeof(char));	// assigning memory to c
	*c = 'A';	// storing 'A' at the memeory pointer c is pointing to
	PrintAlphabets(c);
}