// WRITE A PROGRAM TO REMOVE BLANK SPACE IN A STRING
/*#include <stdio.h>
#include <string.h>

int main()
{
    char s[1000];
    int i, k = 0;
    printf("Enter  the string : ");
    gets(s);

    for (i = 0; s[i]; i++)
    {
        s[i] = s[i + k];

        if (s[i] == ' ' || s[i] == '\t')
        {
            k++;
            i--;
        }
    }
    printf("string after removing all blank spaces:");

    printf("%s", s);

    return 0;
}*/
/*#include <stdio.h>
#include <string.h>

void deleteblankspaces(char *s)
{
    int i, k = 0;

    for (i = 0; s[i]; i++)
    {
        s[i] = s[i + k];

        if (s[i] == ' ' || s[i] == '\t')
        {
            k++;
            i--;
        }
    }
}

int main()
{

    char s[1000];

    printf("Enter  the string : ");
    gets(s);

    deleteblankspaces(s);
    printf("string after removing all duplicates:");

    printf("%s", s);

    return 0;
}*/
// WRITE A PROGRAM TO PRINT HIGHEST FREQUENCY CHARACTER IN A STRING
#include <stdio.h>
#include <string.h>
 
int main()
{
    char str[100], result;
    int i, len;
    int max = 0;
    int freq[256] = {0};
    printf("C Program to Find Maximum Occurring Character in a String \n");
    printf("Please Enter a String :  ");
    scanf("%[^\n]", str);
    len = strlen(str);
    for(i = 0; i < len; i++)
    {
        freq[str[i]]++;
    }
    for(i = 0; i < len; i++)
    {
        if(max <= freq[str[i]])
        {
            max = freq[str[i]];
            result = str[i];
        }
    }
    printf("\n Maximum Occurring Character in a String %s is '%c'  %d times", str, result, max);
    return 0;
}