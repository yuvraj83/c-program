//FUNCTION AND RECURSION
//WRITE A FUNCTION TO FIND SUM OF DIGIT OF A NUMBER
/*#include<stdio.h>
int sum(int n);
int main()

{ 
   //  printf("enter number");
//scanf("%d",&n);

    printf("sum is %d\n",sum(9));
    return 0;
}
int sum(int n){
      
    
    if (n==1)
    {
        return 1;
    }
    
        int sumNm=sum(n-1);
      int  sumN=sumNm+n;
       return sumN;
    
    
}*/
//WRITE A FUNCTION TO FIND SQUARE ROOT OF A NUMBER
/*#include<stdio.h>
#include<math.h>

int main()
{
    float Nm1,n;
    
    printf("enter number");
    scanf("%f",&n);
     Nm1= pow(n,0.5);
  printf("the square of number is %f\n",Nm1);
    return 0;
}
*/
//MAKE YOUR OWN POW FUNCTION

/*#include<stdio.h>


int main()
{
    int base,exponent;
    int result =1;
    
    printf("enterbase  number");
    scanf("%d",&base);
    printf("enter exponent  number");
    scanf("%d",&exponent);
    for ( exponent; exponent > 0; exponent--)
    {
        result=result*base;
    }

  printf("the pow function of number is %ld\n",result);
    return 0;
}*/
//WRITE A FUNCTION TO PRINT HOT OR COLD DEPEND ON THE TEMPERATURE USER ENTERS
/*#include<stdio.h>
#include<stdlib.h>

int main (){
    int t;
    printf("enter temperature:\n" );
    scanf("%d",&t);
    if (t>37)
    {
        printf("hot");
    }
    else if((t<37)&&(t>8))
    {
        printf("normal temp");
    }
    else{
        printf("cold");
    }
    printf("\ttemp is %d",t);
    
    return 0;
}*/