/*#include<stdio.h>
int main()
{
    int a,b,perimeter;
    printf("enter first number:\n");
    scanf("%d",&a);
     printf("enter second number:\n");
    scanf("%d",&b);
    perimeter = 2*(a+b);
    printf("perimetr is %d\n",perimeter);
    return 0;
}
#include<stdio.h>
int main()
{
    int n,cube;
    printf("enter  number:\n");
    scanf("%d",&n);
    cube=n*n*n;
    printf("cube is %d\n",cube);
    

    return 0;
}*/
#include<stdio.h>
int main()
{
    int num,fact=1;
        printf("number is:\n");
        scanf("%d",&num);
   for (int i = 1; i <=num; i++)
   {
    fact=fact*i;
   }
   
   
    printf("the number%d is %d ",num,fact);
    return 0;

}