#include <stdio.h>
#include <stdlib.h>

// Dynamic memory allocation problem
// ABC Pvt Ltd manage record of other companies
// Employeee id can be of any length and it can contain any character.
// for 3 employees,you have to take length of employee id as input in alength integer variable.
// then,you have to take employee id as an input and dissplay it on screen.
// store the employee id in a character array which is allocated dynammically.
// you have to create only one characteer directly.
// EXAMLE 1:
// Enter no of character in your Id
// 45
// dynamically allocate the character array.
// take input from user

// EXAMLE 2:
// Enter no of character in your Id
// 54
// dynamically allocate the character array.
// take input from user

// EXAMLE 3:
// Enter no of character in your Id
// 67
// dynamically allocate the character array.
// take input from user
int main()
{
    int chars, i = 0;
    char *ptr;
   char a,b;
    while (i < 3)
    {
    printf("Employee %d:Enter the number of character in your Employee Id \n",i+1);
    scanf("%d",&chars);
    getchar();
    printf("enter the value of a\n");
    scanf("%c",&a );
    getchar();
    printf("enter the value of b\n");
    scanf("%c",&b );
    getchar();
    ptr =(char *)malloc((chars+1)*sizeof(char));
    printf("enter your employee id\n");
    scanf("%s",ptr);
    getchar();
    printf("your employee id is %s\n",ptr);
    free(ptr);
        i = i + 1;
    }

    return 0;
}
//not give the input of 'a'because print Enter as valid character so fix this problem
// so we use getchar();
#include<stdio.h>
#include<stdio.h>

int (isPalindrome(int num)){
    return 1;
}
int main()
{
    //palidrome number make
    int number ;
    printf("Enter a number to check whether it is a palindrome or not \n");
    scanf("%d",&number);
    //your task is to implement the function
    if (isPalindrome(number))
    {
        printf("This number is palindrome \n");
    }
    else{
        printf("This number is not a palindrome \n");

    }
    
    return 0;
}


//COMMAND LINE ARGUMENT
   /*you have to create a command line utility to add/subtract/multiply /divide two number 
    first command line argument  of your c programs must be the operation
    the enxt argument being the two numbers.*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(int argc, char  *argv[])
{
    char * operation;
    int num1,num2;
    operation = argv[1];
    num1 = atoi(argv[2]);
   num2 = atoi(argv[3]);
// ATOI IS A function which convert string into integer.

   printf("operation is %s\n",operation);
   printf("Num1 is %d\n",num1);
   printf("Num2 is %d\n",num2);
   if (strcmp(operation,"add")==0)
   {
    printf("%d\n",num1+num2);
   }

   else if (strcmp(operation,"subtract")==0)
   {
    printf("%d\n",num1-num2);
   }
   else if (strcmp(operation,"multiply")==0)
   {
    printf("%d\n",num1*num2);
   }
   else if (strcmp(operation,"divide")==0)
   {
    printf("%d\n",num1/num2);
   }
    return 0;
}
/*OUTPUT:1
 .\tut71.exe add 3 5
operation is add
Num1 is 3
Num2 is 5
8*/